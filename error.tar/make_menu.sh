grep -o '<a href="[^"]*">[^<]*</a>' index.html | while read -r line; do
    href=$(echo "$line" | sed -E 's/.*href="([^"]*)".*/\1/')
    
    # hrefが "#" で始まらない、かつ ".html" で終わるものだけを対象とする
    if [[ "$href" != "#"* ]] && [[ "$href" == *.html ]]; then
        if [ ! -f "$href" ]; then
            cp index.html "$href"
            echo "作成しました: $href"
        else
            echo "既に存在します: $href"
        fi
    fi
done