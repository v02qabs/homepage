import argparse
import sys
from google import genai
from google.genai import types


def main():
    # コマンドライン引数の設定
    parser = argparse.ArgumentParser(
        description="Gemini APIを使ってテキストファイルを処理します。"
    )
    parser.add_argument("input_file", help="入力テキストファイルのパス")
    parser.add_argument("prompt", help="Geminiへのプロンプト（指示文）")
    parser.add_argument("output_file", help="出力テキストファイルのパス")

    args = parser.parse_args()

    # 1. 入力ファイルの読み込み
    try:
        with open(args.input_file, "r", encoding="utf-8") as f:
            file_content = f.read()
    except Exception as e:
        print(f"エラー: 入力ファイルを開けませんでした ({args.input_file}): {e}")
        sys.exit(1)

    # 2. プロンプトとファイル内容を結合
    # プロンプトの後にファイル内容を渡す構成にしています
    full_prompt = f"{args.prompt}\n\n--- 対象データ ---\n{file_content}"

    # 3. Gemini APIの呼び出し (gemini-2.5-flash を使用)
    try:
        # クライアントの初期化（環境変数 GEMINI_API_KEY を自動読み込み）
        client = genai.Client()

        print(
            f"Gemini (gemini-3.5-flash) に処理を依頼中... ({args.input_file})"
        )

        response = client.models.generate_content(
            model="gemini-3.5-flash",
            contents=full_prompt,
        )

        output_text = response.text

    except Exception as e:
        print(f"エラー: Gemini APIの呼び出しに失敗しました: {e}")
        sys.exit(1)

    # 4. 出力ファイルへの書き込み
    try:
        with open(args.output_file, "w", encoding="utf-8") as f:
            f.write(output_text)
        print(f"完了しました。結果を {args.output_file} に保存しました。")
    except Exception as e:
        print(f"エラー: 出力ファイルを保存できませんでした ({args.output_file}): {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()